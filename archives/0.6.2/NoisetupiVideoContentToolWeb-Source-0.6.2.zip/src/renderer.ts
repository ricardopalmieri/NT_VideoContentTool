import type { EffectNode, Layer, ProjectDocument } from "./types";
import { resolveAssetUrl } from "./web-platform";

const vertexSource = `#version 300 es
in vec2 a_position;
out vec2 v_uv;
void main() {
  v_uv = a_position * .5 + .5;
  gl_Position = vec4(a_position, 0.0, 1.0);
}`;

const fragmentSource = `#version 300 es
precision highp float;
uniform sampler2D u_texture;
uniform sampler2D u_texture_r;
uniform sampler2D u_texture_g;
uniform sampler2D u_texture_b;
uniform vec2 u_resolution;
uniform float u_time;
uniform int u_effect;
uniform float u_mix;
uniform float u_p0;
uniform float u_p1;
uniform float u_p2;
uniform float u_p3;
uniform float u_p4;
uniform float u_p5;
uniform float u_p6;
uniform float u_p7;
in vec2 v_uv;
out vec4 outColor;

float hash(vec2 p) {
  return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
}
vec4 source(vec2 uv) {
  if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) return vec4(0.0);
  return texture(u_texture, uv);
}
float lum(vec3 c) { return dot(c, vec3(.299, .587, .114)); }
vec4 bloomExtract(vec2 uv) {
  vec4 sampleColor = source(uv);
  float brightness = max(sampleColor.r, max(sampleColor.g, sampleColor.b));
  float knee = max(.0001, u_p3);
  float contribution = smoothstep(u_p0 - knee, u_p0 + knee, brightness);
  return sampleColor * contribution;
}
float edgeAt(vec2 uv, float thickness) {
  vec2 px = thickness / u_resolution;
  float tl = lum(source(uv + px * vec2(-1., 1.)).rgb);
  float tc = lum(source(uv + px * vec2( 0., 1.)).rgb);
  float tr = lum(source(uv + px * vec2( 1., 1.)).rgb);
  float ml = lum(source(uv + px * vec2(-1., 0.)).rgb);
  float mr = lum(source(uv + px * vec2( 1., 0.)).rgb);
  float bl = lum(source(uv + px * vec2(-1.,-1.)).rgb);
  float bc = lum(source(uv + px * vec2( 0.,-1.)).rgb);
  float br = lum(source(uv + px * vec2( 1.,-1.)).rgb);
  float gx = -tl - 2. * ml - bl + tr + 2. * mr + br;
  float gy = -bl - 2. * bc - br + tl + 2. * tc + tr;
  float alphaEdge = abs(source(uv + px).a - source(uv - px).a);
  return max(length(vec2(gx, gy)), alphaEdge);
}
void main() {
  vec2 uv = v_uv;
  vec4 c = source(uv);

  if (u_effect == 1) {
    if (u_p0 < 1.5) uv.x = u_p1 - abs(uv.x - u_p1);
    else if (u_p0 < 2.5) uv.y = u_p1 - abs(uv.y - u_p1);
    else uv = vec2(u_p1) - abs(uv - vec2(u_p1));
    c = source(uv);
  } else if (u_effect == 2) {
    vec2 fuv = (uv - .5) * (1.0 - u_p1) + .5 + vec2(u_p2, u_p3);
    vec4 echo = source(fuv);
    c = mix(c, echo, clamp(u_p0, 0.0, .95));
  } else if (u_effect == 3) {
    c.rgb += u_p0;
    c.rgb = (c.rgb - .5) * u_p1 + .5;
    float gray = lum(c.rgb);
    c.rgb = mix(vec3(gray), c.rgb, u_p2);
    c.rgb = pow(max(c.rgb, 0.0), vec3(1.0 / max(.05, u_p3)));
  } else if (u_effect == 4) {
    vec2 p = uv - .5;
    float r = length(p) / max(.05, u_p2);
    float a = atan(p.y, p.x) + u_p1;
    float seg = 6.2831853 / max(2.0, u_p0);
    a = abs(mod(a + seg * .5, seg) - seg * .5);
    c = source(vec2(cos(a), sin(a)) * r + .5);
  } else if (u_effect == 5) {
    vec2 d = (u_p1 < .5 ? vec2(max(.01, u_p0), 0.0) : vec2(0.0, max(.01, u_p0))) / u_resolution;
    c = source(uv) * .227027;
    c += source(uv + d * 1.384615) * .316216;
    c += source(uv - d * 1.384615) * .316216;
    c += source(uv + d * 3.230769) * .070270;
    c += source(uv - d * 3.230769) * .070270;
  } else if (u_effect == 6) {
    if (uv.x < u_p0 || uv.x > u_p1 || uv.y < u_p2 || uv.y > u_p3) c = vec4(0.0);
  } else if (u_effect == 7) {
    float e = smoothstep(u_p1, u_p1 + .12, edgeAt(uv, 1.0)) * u_p0;
    vec3 edgeColor = mix(vec3(e), c.rgb * e, u_p2);
    c = vec4(edgeColor, max(c.a * e, e));
  } else if (u_effect == 8) {
    vec3 key = vec3(abs(u_p0 * 6.0 - 3.0) - 1.0, 2.0 - abs(u_p0 * 6.0 - 2.0), 2.0 - abs(u_p0 * 6.0 - 4.0));
    key = clamp(key, 0.0, 1.0);
    float dist = distance(c.rgb, key);
    c.a *= smoothstep(u_p1, u_p1 + max(.001, u_p2), dist);
  } else if (u_effect == 9) {
    float e = edgeAt(uv, max(.5, u_p2));
    float line = smoothstep(u_p1, u_p1 + max(.005, u_p3), e);
    float axis = u_p4 < .5 ? uv.x : u_p4 < 1.5 ? (1.0 - uv.x) : u_p4 < 2.5 ? uv.y : (1.0 - uv.y);
    float organic = (hash(floor(uv * u_resolution / 8.0)) - .5) * u_p5;
    float reveal = 1.0 - smoothstep(u_p0 - .035, u_p0 + .035, axis + organic);
    if (u_p7 > .5) reveal = 1.0 - reveal;
    c = vec4(c.rgb * line, max(c.a, line) * reveal);
  } else if (u_effect == 20) {
    vec4 original = c;
    vec4 shifted = vec4(
      texture(u_texture_r, uv).r,
      texture(u_texture_g, uv).g,
      texture(u_texture_b, uv).b,
      original.a
    );
    c = shifted;
  } else if (u_effect == 21) {
    float n = hash(uv * u_resolution * max(.1, u_p1) + u_time);
    c.rgb += (n - .5) * u_p0;
  } else if (u_effect == 22) {
    float frame = floor(u_time * max(.1, u_p1));
    float bands = max(2., u_p2);
    float band = floor(uv.y * bands);
    float eventNoise = hash(vec2(band, frame));
    float gate = step(1.0 - max(.0001, clamp(u_p0, 0.0, 1.0)), eventNoise) * step(.0001, u_p0);
    float shift = (hash(vec2(frame, band * 1.37)) - .5) * u_p3 * gate;
    float micro = (hash(vec2(floor(uv.y * bands * 5.0), frame + 18.0)) - .5) * u_p3 * .18 * gate;
    vec2 shiftedUv = uv + vec2(shift + micro, 0.0);
    float split = u_p4 / u_resolution.x * gate;
    vec4 glitched = source(shiftedUv);
    glitched.r = source(shiftedUv + vec2(split, 0)).r;
    glitched.b = source(shiftedUv - vec2(split, 0)).b;
    float scan = sin(uv.y * u_resolution.y * 3.14159265) * .5 + .5;
    glitched.rgb *= 1.0 - scan * u_p5 * gate;
    c = glitched;
  } else if (u_effect == 23) {
    float scan = sin(uv.y * max(20., u_p1) * 3.14159) * .5 + .5;
    float tracking = step(.96, hash(vec2(floor(uv.y * 60.), floor(u_time * 5.)))) * u_p2;
    c.rgb *= 1.0 - scan * .16 * u_p0;
    c.rgb += tracking;
    c.r = source(uv + vec2(.002 * u_p0, 0)).r;
    c.b = source(uv - vec2(.003 * u_p0, 0)).b;
  } else if (u_effect == 24) {
    vec2 shake = vec2(hash(vec2(floor(u_time * u_p1), 1.)), hash(vec2(2., floor(u_time * u_p1)))) - .5;
    c = source(uv + shake * u_p0);
  } else if (u_effect == 25) {
    vec4 original = c;
    vec2 d = vec2(max(.5, u_p1)) / u_resolution;
    vec4 bloom = bloomExtract(uv) * .08;
    bloom += bloomExtract(uv + vec2( d.x, 0.0)) * .09;
    bloom += bloomExtract(uv + vec2(-d.x, 0.0)) * .09;
    bloom += bloomExtract(uv + vec2(0.0,  d.y)) * .09;
    bloom += bloomExtract(uv + vec2(0.0, -d.y)) * .09;
    bloom += bloomExtract(uv + d) * .065;
    bloom += bloomExtract(uv - d) * .065;
    bloom += bloomExtract(uv + vec2( d.x, -d.y)) * .065;
    bloom += bloomExtract(uv + vec2(-d.x,  d.y)) * .065;
    vec2 d2 = d * 2.25;
    bloom += bloomExtract(uv + vec2( d2.x, 0.0)) * .04;
    bloom += bloomExtract(uv + vec2(-d2.x, 0.0)) * .04;
    bloom += bloomExtract(uv + vec2(0.0,  d2.y)) * .04;
    bloom += bloomExtract(uv + vec2(0.0, -d2.y)) * .04;
    bloom += bloomExtract(uv + d2) * .02;
    bloom += bloomExtract(uv - d2) * .02;
    bloom += bloomExtract(uv + vec2( d2.x, -d2.y)) * .02;
    bloom += bloomExtract(uv + vec2(-d2.x,  d2.y)) * .02;
    vec2 d4 = d * 4.5;
    bloom += bloomExtract(uv + vec2( d4.x, 0.0)) * .02;
    bloom += bloomExtract(uv + vec2(-d4.x, 0.0)) * .02;
    bloom += bloomExtract(uv + vec2(0.0,  d4.y)) * .02;
    bloom += bloomExtract(uv + vec2(0.0, -d4.y)) * .02;
    float bloomLum = lum(bloom.rgb);
    bloom.rgb = mix(vec3(bloomLum), bloom.rgb, u_p4);
    vec4 bloomed = original;
    bloomed.rgb += bloom.rgb * u_p2;
    bloomed.a = max(original.a, bloom.a * min(1.0, u_p2));
    c = bloomed;
  }
  if (u_effect != 0) c = mix(source(v_uv), c, clamp(u_mix, 0.0, 1.0));
  outColor = clamp(c, 0.0, 1.0);
}`;

interface Target {
  framebuffer: WebGLFramebuffer;
  texture: WebGLTexture;
}

interface EffectHistory {
  targets: Target[];
  writeIndex: number;
  count: number;
  lastTime: number;
}

export class ComposerRenderer {
  readonly canvas: HTMLCanvasElement;
  private gl: WebGL2RenderingContext;
  private program: WebGLProgram;
  private sourceTexture: WebGLTexture;
  private targets: Target[] = [];
  private compTarget!: Target;
  private raster = document.createElement("canvas");
  private ctx = this.raster.getContext("2d", { willReadFrequently: false })!;
  private media = new Map<string, HTMLImageElement | HTMLVideoElement>();
  private videoFrameCache = new Map<string, HTMLCanvasElement>();
  private videoFrameCacheTime = new Map<string, number>();
  private project!: ProjectDocument;
  private uniforms = new Map<string, WebGLUniformLocation>();
  private effectHistories = new Map<string, EffectHistory>();
  private previewScale = 1;
  private activeScale = 1;
  private previewPlaying = false;

  constructor(canvas: HTMLCanvasElement, private readonly invalidate: () => void = () => undefined) {
    this.canvas = canvas;
    const gl = canvas.getContext("webgl2", {
      alpha: true,
      antialias: true,
      premultipliedAlpha: true,
      preserveDrawingBuffer: true,
    });
    if (!gl) throw new Error("WebGL2 is required.");
    this.gl = gl;
    this.program = this.createProgram(vertexSource, fragmentSource);
    this.sourceTexture = this.createTexture();
    const buffer = gl.createBuffer()!;
    gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, 1]), gl.STATIC_DRAW);
    const location = gl.getAttribLocation(this.program, "a_position");
    gl.enableVertexAttribArray(location);
    gl.vertexAttribPointer(location, 2, gl.FLOAT, false, 0, 0);
    for (const name of ["u_texture", "u_texture_r", "u_texture_g", "u_texture_b", "u_resolution", "u_time", "u_effect", "u_mix", ...Array.from({ length: 8 }, (_, i) => `u_p${i}`)]) {
      this.uniforms.set(name, gl.getUniformLocation(this.program, name)!);
    }
  }

  setProject(project: ProjectDocument, _root: string) {
    this.project = project;
    const { width, height } = project.settings;
    const max = this.gl.getParameter(this.gl.MAX_TEXTURE_SIZE);
    if (width > max || height > max) throw new Error(`Canvas exceeds GPU limit (${max}px).`);
    if (width * height > 33_554_432) throw new Error("Canvas exceeds the safe GPU pixel limit.");
    this.resizeRenderSurface(this.activeScale);
    for (const layer of project.layers) this.preload(layer, false);
  }

  setPreviewScale(scale: number) {
    this.previewScale = Math.max(.25, Math.min(1, scale));
  }

  private resizeRenderSurface(scale: number) {
    if (!this.project) return;
    const width = Math.max(16, Math.round(this.project.settings.width * scale));
    const height = Math.max(16, Math.round(this.project.settings.height * scale));
    const canvasResized = this.canvas.width !== width || this.canvas.height !== height;
    if (canvasResized) {
      this.canvas.width = width;
      this.canvas.height = height;
    }
    const rasterResized = this.raster.width !== width || this.raster.height !== height;
    if (rasterResized) {
      this.raster.width = width;
      this.raster.height = height;
    }
    if (canvasResized || rasterResized || this.targets.length !== 2 || !this.compTarget) {
      this.resetTargets();
    }
    this.activeScale = scale;
  }

  private ensureRenderScale(scale: number) {
    if (Math.abs(this.activeScale - scale) > .001) this.resizeRenderSurface(scale);
  }

  private assetUrl(relative: string) {
    return resolveAssetUrl(relative);
  }

  preload(layer: Layer, fitToCanvas = false) {
    if (!layer.asset || this.media.has(layer.id)) return;
    const source = this.assetUrl(layer.asset);
    // A lightweight project may be opened before its external media is relinked.
    // Do not register an empty media element: a video without a source never
    // fires loadedmetadata and used to stall the whole render queue.
    if (!source) return;
    const fitMedia = (sourceWidth: number, sourceHeight: number) => {
      if (!sourceWidth || !sourceHeight || !this.project) return;
      const coverage = layer.kind === "guide" ? 1 : .8;
      const scale = Math.min(
        this.project.settings.width * coverage / sourceWidth,
        this.project.settings.height * coverage / sourceHeight,
      );
      layer.width = sourceWidth * scale;
      layer.height = sourceHeight * scale;
    };
    if (layer.kind === "video") {
      const video = document.createElement("video");
      video.crossOrigin = "anonymous";
      video.muted = true;
      video.preload = "auto";
      video.playsInline = true;
      video.addEventListener("loadedmetadata", () => {
        if (fitToCanvas) fitMedia(video.videoWidth, video.videoHeight);
        if (!layer.sourceOut || layer.sourceOut <= layer.sourceIn) layer.sourceOut = video.duration || 0;
        this.invalidate();
      }, { once: true });
      video.addEventListener("loadeddata", () => this.invalidate(), { once: true });
      this.media.set(layer.id, video);
      video.src = source;
      video.load();
    } else {
      const image = new Image();
      image.crossOrigin = "anonymous";
      image.decoding = "async";
      image.addEventListener("load", () => {
        if (fitToCanvas) fitMedia(image.naturalWidth, image.naturalHeight);
        this.invalidate();
      }, { once: true });
      this.media.set(layer.id, image);
      image.src = source;
    }
  }

  hitTestAll(x: number, y: number, time: number): Layer[] {
    const hits: Layer[] = [];
    for (const layer of this.project.layers) {
      if (!layer.visible || time < layer.startTime || time > layer.endTime) continue;
      if (this.evaluated(layer, "opacity", time) * this.fadeEnvelope(layer, time) <= .001) continue;
      const centerX = this.evaluated(layer, "x", time);
      const centerY = this.evaluated(layer, "y", time);
      const scaleX = Math.abs(this.evaluated(layer, "scaleX", time));
      const scaleY = Math.abs(this.evaluated(layer, "scaleY", time));
      if (scaleX < .0001 || scaleY < .0001) continue;
      const rotation = -this.evaluated(layer, "rotation", time) * Math.PI / 180;
      const dx = x - centerX;
      const dy = y - centerY;
      const localX = (dx * Math.cos(rotation) - dy * Math.sin(rotation)) / scaleX;
      const localY = (dx * Math.sin(rotation) + dy * Math.cos(rotation)) / scaleY;
      const width = Math.abs(this.evaluated(layer, "width", time));
      const height = layer.geometry === "line"
        ? Math.max(12, this.evaluated(layer, "strokeWidth", time) * 2)
        : Math.abs(this.evaluated(layer, "height", time));
      if (Math.abs(localX) <= width / 2 && Math.abs(localY) <= height / 2) hits.push(layer);
    }
    return hits;
  }

  hitTest(x: number, y: number, time: number): Layer | undefined {
    return this.hitTestAll(x, y, time)[0];
  }

  removeMedia(id: string) {
    const item = this.media.get(id);
    if (item instanceof HTMLVideoElement) {
      item.pause();
      item.removeAttribute("src");
      item.load();
    }
    this.media.delete(id);
    this.videoFrameCache.delete(id);
    this.videoFrameCacheTime.delete(id);
  }

  dispose() {
    for (const id of [...this.media.keys()]) this.removeMedia(id);
    this.clearEffectHistories();
    const gl = this.gl;
    const renderTargets = this.compTarget ? [...this.targets, this.compTarget] : this.targets;
    for (const target of renderTargets) {
      gl.deleteFramebuffer(target.framebuffer);
      gl.deleteTexture(target.texture);
    }
    this.targets = [];
    gl.deleteTexture(this.sourceTexture);
    gl.deleteProgram(this.program);
  }

  mediaDuration(id: string) {
    const media = this.media.get(id);
    return media instanceof HTMLVideoElement && Number.isFinite(media.duration) ? media.duration : 0;
  }

  private sourceTimeFor(layer: Layer, timelineTime: number, mediaDuration: number) {
    const sourceIn = Math.max(0, Math.min(mediaDuration, layer.sourceIn || layer.sourceOffset || 0));
    const configuredOut = layer.sourceOut > sourceIn ? layer.sourceOut : mediaDuration;
    const sourceOut = Math.max(sourceIn, Math.min(mediaDuration, configuredOut));
    const span = Math.max(.001, sourceOut - sourceIn);
    const speed = Math.max(.05, Math.abs(this.evaluated(layer, "playbackRate", timelineTime) || 1));
    let elapsed = Math.max(0, timelineTime - layer.startTime) * speed;
    if (layer.loop) elapsed %= span;
    else elapsed = Math.min(span, elapsed);
    const sourceTime = layer.reverse ? sourceOut - elapsed : sourceIn + elapsed;
    return Math.max(0, Math.min(Math.max(0, mediaDuration - .001), sourceTime));
  }

  private fadeEnvelope(layer: Layer, time: number) {
    let value = 1;
    if (layer.fadeInEnd > layer.fadeInStart) value *= time <= layer.fadeInStart ? 0 : time < layer.fadeInEnd ? (time - layer.fadeInStart) / (layer.fadeInEnd - layer.fadeInStart) : 1;
    if (layer.fadeOutEnd > layer.fadeOutStart) value *= time <= layer.fadeOutStart ? 1 : time < layer.fadeOutEnd ? 1 - (time - layer.fadeOutStart) / (layer.fadeOutEnd - layer.fadeOutStart) : 0;
    return Math.max(0, Math.min(1, value));
  }

  setPlaybackState(playing: boolean, timelineTime: number) {
    this.previewPlaying = playing;
    for (const layer of this.project?.layers || []) {
      if (layer.kind !== "video") continue;
      const video = this.media.get(layer.id);
      if (!(video instanceof HTMLVideoElement)) continue;
      if (!playing || layer.reverse || timelineTime < layer.startTime || timelineTime > layer.endTime) {
        video.pause();
        continue;
      }
      const target = this.sourceTimeFor(layer, timelineTime, video.duration || 0);
      const speed = Math.max(.05, Math.min(8, Math.abs(this.evaluated(layer, "playbackRate", timelineTime) || 1)));
      video.playbackRate = speed;
      if (video.readyState >= 1 && Math.abs(video.currentTime - target) > .18) video.currentTime = target;
      void video.play().catch(() => undefined);
    }
  }

  private createProgram(vertex: string, fragment: string) {
    const gl = this.gl;
    const compile = (type: number, source: string) => {
      const shader = gl.createShader(type)!;
      gl.shaderSource(shader, source);
      gl.compileShader(shader);
      if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(shader) || "Shader error");
      return shader;
    };
    const program = gl.createProgram()!;
    gl.attachShader(program, compile(gl.VERTEX_SHADER, vertex));
    gl.attachShader(program, compile(gl.FRAGMENT_SHADER, fragment));
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(program) || "Shader link error");
    gl.useProgram(program);
    return program;
  }

  private createTexture(): WebGLTexture {
    const gl = this.gl;
    const texture = gl.createTexture()!;
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    return texture;
  }

  private createTarget(): Target {
    const gl = this.gl;
    const texture = this.createTexture();
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, this.canvas.width, this.canvas.height, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    const framebuffer = gl.createFramebuffer()!;
    gl.bindFramebuffer(gl.FRAMEBUFFER, framebuffer);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, texture, 0);
    const status = gl.checkFramebufferStatus(gl.FRAMEBUFFER);
    if (status !== gl.FRAMEBUFFER_COMPLETE) {
      gl.deleteFramebuffer(framebuffer);
      gl.deleteTexture(texture);
      throw new Error(`WebGL framebuffer is incomplete (${status}).`);
    }
    return { framebuffer, texture };
  }

  private resetTargets() {
    const gl = this.gl;
    const existing = this.compTarget ? [...this.targets, this.compTarget] : this.targets;
    for (const target of existing) {
      gl.deleteFramebuffer(target.framebuffer);
      gl.deleteTexture(target.texture);
    }
    this.targets = [this.createTarget(), this.createTarget()];
    this.compTarget = this.createTarget();
    this.clearEffectHistories();
  }

  private clearEffectHistories() {
    const gl = this.gl;
    for (const history of this.effectHistories.values()) {
      for (const target of history.targets) {
        gl.deleteFramebuffer(target.framebuffer);
        gl.deleteTexture(target.texture);
      }
    }
    this.effectHistories.clear();
  }

  private easedAmount(keyframe: { easing: string; curve?: number }, amount: number) {
    const t = Math.max(0, Math.min(1, amount));
    if (keyframe.easing === "hold") return 0;
    if (keyframe.easing === "easeIn") return t * t;
    if (keyframe.easing === "easeOut") return 1 - (1 - t) * (1 - t);
    if (keyframe.easing === "easeInOut") return t < .5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
    if (keyframe.easing === "bezier") {
      const smooth = t * t * (3 - 2 * t);
      const tension = Math.max(0, Math.min(1, keyframe.curve ?? .75));
      return t + (smooth - t) * tension;
    }
    return t;
  }

  private evaluated(layer: Layer, property: keyof Layer, time: number): number {
    const fallback = Number(layer[property]);
    const keys = layer.keyframes[String(property)];
    if (!keys?.length) return fallback;
    const ordered = [...keys].sort((a, b) => a.time - b.time);
    if (time <= ordered[0].time) return ordered[0].value;
    if (time >= ordered.at(-1)!.time) return ordered.at(-1)!.value;
    const rightIndex = ordered.findIndex((key) => key.time >= time);
    const a = ordered[rightIndex - 1];
    const b = ordered[rightIndex];
    const t = this.easedAmount(a, (time - a.time) / (b.time - a.time));
    return a.value + (b.value - a.value) * t;
  }

  layerValue(layer: Layer, property: keyof Layer, time: number) {
    return this.evaluated(layer, property, time);
  }

  private async seekVideo(video: HTMLVideoElement, time: number) {
    if (video.readyState < 1) {
      if (!video.currentSrc && !video.src) return false;
      const metadataReady = await new Promise<boolean>((resolve) => {
        let settled = false;
        const finish = (ready: boolean) => {
          if (settled) return;
          settled = true;
          window.clearTimeout(timeout);
          video.removeEventListener("loadedmetadata", onReady);
          video.removeEventListener("error", onError);
          video.removeEventListener("abort", onError);
          resolve(ready);
        };
        const onReady = () => finish(true);
        const onError = () => finish(false);
        const timeout = window.setTimeout(() => finish(video.readyState >= 1), 1000);
        video.addEventListener("loadedmetadata", onReady);
        video.addEventListener("error", onError);
        video.addEventListener("abort", onError);
      });
      if (!metadataReady) return false;
    }
    const target = Math.max(0, Math.min(video.duration || time, time));
    if (Math.abs(video.currentTime - target) < 1 / Math.max(1, this.project.settings.fps)) return true;
    await new Promise<void>((resolve) => {
      const done = () => resolve();
      video.addEventListener("seeked", done, { once: true });
      video.currentTime = target;
      window.setTimeout(done, 500);
    });
    return true;
  }

  private syncVideoPlayback(layerId: string, video: HTMLVideoElement, sourceTime: number, speed: number) {
    video.playbackRate = speed;
    if (Math.abs(video.currentTime - sourceTime) > .32 && !video.seeking) {
      this.captureVideoFrame(layerId, video, true);
      video.currentTime = sourceTime;
    }
    if (video.paused && !video.seeking) void video.play().catch(() => undefined);
  }

  private captureVideoFrame(layerId: string, video: HTMLVideoElement, force = false) {
    if (video.readyState < 2 || !video.videoWidth || !video.videoHeight) return;
    const now = performance.now();
    if (!force && now - (this.videoFrameCacheTime.get(layerId) || 0) < 180) return;
    const maxDimension = 1280;
    const scale = Math.min(1, maxDimension / Math.max(video.videoWidth, video.videoHeight));
    const width = Math.max(1, Math.round(video.videoWidth * scale));
    const height = Math.max(1, Math.round(video.videoHeight * scale));
    let frame = this.videoFrameCache.get(layerId);
    if (!frame) {
      frame = document.createElement("canvas");
      this.videoFrameCache.set(layerId, frame);
    }
    if (frame.width !== width || frame.height !== height) {
      frame.width = width;
      frame.height = height;
    }
    frame.getContext("2d")?.drawImage(video, 0, 0, width, height);
    this.videoFrameCacheTime.set(layerId, now);
  }

  private evaluatedColor(layer: Layer, property: "fill" | "stroke", time: number) {
    const fallback = layer[property];
    const keys = layer.keyframes[`${property}Color`];
    if (!keys?.length) return fallback;
    const ordered = [...keys].sort((a, b) => a.time - b.time);
    const decode = (value: number) => [
      (Math.round(value) >> 16) & 255,
      (Math.round(value) >> 8) & 255,
      Math.round(value) & 255,
    ];
    if (time <= ordered[0].time) return `#${Math.round(ordered[0].value).toString(16).padStart(6, "0")}`;
    if (time >= ordered.at(-1)!.time) return `#${Math.round(ordered.at(-1)!.value).toString(16).padStart(6, "0")}`;
    const rightIndex = ordered.findIndex((key) => key.time >= time);
    const a = ordered[rightIndex - 1];
    const b = ordered[rightIndex];
    const amount = this.easedAmount(a, (time - a.time) / (b.time - a.time));
    const from = decode(a.value);
    const to = decode(b.value);
    const rgb = from.map((channel, index) => Math.round(channel + (to[index] - channel) * amount));
    return `#${rgb.map((channel) => channel.toString(16).padStart(2, "0")).join("")}`;
  }

  layerColor(layer: Layer, property: "fill" | "stroke", time: number) {
    return this.evaluatedColor(layer, property, time);
  }

  private drawGeometry(layer: Layer, time: number, layerOpacity: number) {
    const ctx = this.ctx;
    const w = this.evaluated(layer, "width", time);
    const h = this.evaluated(layer, "height", time);
    ctx.beginPath();
    if (layer.geometry === "ellipse") ctx.ellipse(0, 0, w / 2, h / 2, 0, 0, Math.PI * 2);
    else if (layer.geometry === "triangle") {
      ctx.moveTo(0, -h / 2);
      ctx.lineTo(w / 2, h / 2);
      ctx.lineTo(-w / 2, h / 2);
      ctx.closePath();
    } else if (layer.geometry === "polygon") {
      for (let i = 0; i < 6; i++) {
        const a = -Math.PI / 2 + i * Math.PI / 3;
        const point = [Math.cos(a) * w / 2, Math.sin(a) * h / 2];
        i ? ctx.lineTo(point[0], point[1]) : ctx.moveTo(point[0], point[1]);
      }
      ctx.closePath();
    } else if (layer.geometry === "line") {
      ctx.moveTo(-w / 2, 0);
      ctx.lineTo(w / 2, 0);
    } else ctx.rect(-w / 2, -h / 2, w, h);
    if (layer.fillEnabled && layer.geometry !== "line") {
      ctx.globalAlpha = layerOpacity * this.evaluated(layer, "fillOpacity", time);
      ctx.fillStyle = this.evaluatedColor(layer, "fill", time);
      ctx.fill();
    }
    if (layer.strokeEnabled || layer.geometry === "line") {
      ctx.globalAlpha = layerOpacity * this.evaluated(layer, "strokeOpacity", time);
      ctx.strokeStyle = this.evaluatedColor(layer, "stroke", time);
      ctx.lineWidth = this.evaluated(layer, "strokeWidth", time);
      ctx.stroke();
    }
  }

  private async rasterize(
    layer: Layer,
    time: number,
    exporting: boolean,
    opacityMultiplier = 1,
    offsetX = 0,
    offsetY = 0,
  ) {
    const ctx = this.ctx;
    const width = this.raster.width;
    const height = this.raster.height;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, width, height);
    ctx.setTransform(this.activeScale, 0, 0, this.activeScale, 0, 0);
    const x = this.evaluated(layer, "x", time) + offsetX;
    const y = this.evaluated(layer, "y", time) + offsetY;
    const scaleX = this.evaluated(layer, "scaleX", time);
    const scaleY = this.evaluated(layer, "scaleY", time);
    const rotation = this.evaluated(layer, "rotation", time) * Math.PI / 180;
    ctx.translate(x, y);
    ctx.rotate(rotation);
    ctx.scale(scaleX, scaleY);
    const layerOpacity = this.evaluated(layer, "opacity", time) * opacityMultiplier * this.fadeEnvelope(layer, time);
    ctx.globalAlpha = layerOpacity;

    if (layer.kind === "geometry") this.drawGeometry(layer, time, layerOpacity);
    else if (layer.kind === "text") {
      const fontWeight = this.evaluated(layer, "fontWeight", time);
      const fontSize = this.evaluated(layer, "fontSize", time);
      const layerWidth = this.evaluated(layer, "width", time);
      const layerHeight = this.evaluated(layer, "height", time);
      ctx.font = `${fontWeight || 500} ${fontSize || 80}px ${layer.fontFamily || "IBM Plex Sans"}`;
      ctx.textAlign = layer.align || "center";
      ctx.textBaseline = "middle";
      const padding = Math.max(2, fontSize * .04);
      const availableWidth = Math.max(1, layerWidth - padding * 2);
      const lineHeight = fontSize * 1.18;
      const lines: string[] = [];
      for (const paragraph of (layer.text || "").split("\n")) {
        const words = paragraph.split(/\s+/).filter(Boolean);
        if (!words.length) {
          lines.push("");
          continue;
        }
        let line = words[0];
        for (const word of words.slice(1)) {
          const candidate = `${line} ${word}`;
          if (ctx.measureText(candidate).width <= availableWidth) line = candidate;
          else {
            lines.push(line);
            line = word;
          }
        }
        lines.push(line);
      }
      const maxLines = Math.max(1, Math.floor(Math.max(lineHeight, layerHeight - padding * 2) / lineHeight));
      const visibleLines = lines.slice(0, maxLines);
      const startY = -(visibleLines.length - 1) * lineHeight / 2;
      const drawX = layer.align === "left" ? -layerWidth / 2 + padding : layer.align === "right" ? layerWidth / 2 - padding : 0;
      ctx.save();
      ctx.beginPath();
      ctx.rect(-layerWidth / 2, -layerHeight / 2, layerWidth, layerHeight);
      ctx.clip();
      visibleLines.forEach((line, index) => {
        const drawY = startY + index * lineHeight;
        if (layer.fillEnabled) {
          ctx.globalAlpha = layerOpacity * this.evaluated(layer, "fillOpacity", time);
          ctx.fillStyle = this.evaluatedColor(layer, "fill", time);
          ctx.fillText(line, drawX, drawY);
        }
        if (layer.strokeEnabled) {
          ctx.globalAlpha = layerOpacity * this.evaluated(layer, "strokeOpacity", time);
          ctx.strokeStyle = this.evaluatedColor(layer, "stroke", time);
          ctx.lineWidth = this.evaluated(layer, "strokeWidth", time);
          ctx.strokeText(line, drawX, drawY);
        }
      });
      ctx.restore();
    } else {
      const media = this.media.get(layer.id);
      if (!media) return false;
      let drawable: CanvasImageSource = media;
      if (media instanceof HTMLVideoElement) {
        // Preview should never wait for media I/O. loadedmetadata/loadeddata
        // invalidate the renderer as soon as the frame can actually be drawn.
        if (media.readyState < 1 && !exporting) return false;
        const sourceTime = this.sourceTimeFor(layer, time, media.duration || 0);
        const speed = Math.max(.05, Math.min(8, Math.abs(this.evaluated(layer, "playbackRate", time) || 1)));
        if (exporting || !this.previewPlaying || layer.reverse) {
          if (!await this.seekVideo(media, sourceTime)) return false;
        } else {
          this.syncVideoPlayback(layer.id, media, sourceTime, speed);
        }
        if (media.readyState < 2) {
          const cachedFrame = this.videoFrameCache.get(layer.id);
          if (exporting || !cachedFrame?.width || !cachedFrame.height) return false;
          drawable = cachedFrame;
        } else {
          this.captureVideoFrame(layer.id, media);
        }
      } else if (!media.complete) {
        await new Promise<void>((resolve) => {
          media.addEventListener("load", () => resolve(), { once: true });
          media.addEventListener("error", () => resolve(), { once: true });
        });
      }
      const sourceW = drawable instanceof HTMLVideoElement
        ? drawable.videoWidth
        : drawable instanceof HTMLImageElement
          ? drawable.naturalWidth
          : drawable.width;
      const sourceH = drawable instanceof HTMLVideoElement
        ? drawable.videoHeight
        : drawable instanceof HTMLImageElement
          ? drawable.naturalHeight
          : drawable.height;
      if (!sourceW || !sourceH) return false;
      const layerWidth = this.evaluated(layer, "width", time);
      const layerHeight = this.evaluated(layer, "height", time);
      ctx.drawImage(drawable, -layerWidth / 2, -layerHeight / 2, layerWidth, layerHeight);
    }
    ctx.globalAlpha = 1;
    return true;
  }

  private effectCode(kind: EffectNode["kind"]) {
    return ({ mirror: 1, feedback: 2, levels: 3, kaleidoscope: 4, blur: 5, crop: 6, edge: 7, colorKey: 8, animaTracer: 9, rgbDelay: 20, noise: 21, glitch: 22, vhs: 23, cameraShake: 24, glow: 25 } as const)[kind];
  }

  private effectParam(effect: EffectNode, key: string, time: number) {
    const fallback = effect.params[key] ?? 0;
    const keys = effect.keyframes?.[key];
    if (!keys?.length) return fallback;
    const ordered = [...keys].sort((a, b) => a.time - b.time);
    if (time <= ordered[0].time) return ordered[0].value;
    if (time >= ordered.at(-1)!.time) return ordered.at(-1)!.value;
    const rightIndex = ordered.findIndex((item) => item.time >= time);
    const a = ordered[rightIndex - 1];
    const b = ordered[rightIndex];
    const amount = this.easedAmount(a, (time - a.time) / (b.time - a.time));
    return a.value + (b.value - a.value) * amount;
  }

  effectValue(effect: EffectNode, key: string, time: number) {
    return this.effectParam(effect, key, time);
  }

  private effectValues(effect: EffectNode, time: number) {
    const p = new Proxy(effect.params, { get: (_, key: string) => this.effectParam(effect, key, time) });
    switch (effect.kind) {
      case "mirror": return [p.mode, p.center];
      case "feedback": return [];
      case "levels": return [p.brightness, p.contrast, p.saturation, p.gamma];
      case "kaleidoscope": return [p.segments, p.rotation, p.zoom];
      case "blur": return [p.radius];
      case "crop": return [p.left, p.right, p.top, p.bottom];
      case "edge": return [p.amount, p.threshold, p.colorize];
      case "colorKey": return [p.hue, p.tolerance, p.softness];
      case "animaTracer": return [p.progress, p.sensitivity, p.thickness, p.softness, p.direction, p.irregularity, 0, p.invert];
      case "rgbDelay": return [p.redDelay, p.greenDelay, p.blueDelay];
      case "noise": return [p.amount, p.scale];
      case "glitch": return [p.amount, p.frequency, p.blockSize, p.shift, p.rgbSplit, p.scanlines];
      case "vhs": return [p.amount, p.scanlines, p.tracking];
      case "cameraShake": return [p.amount, p.speed];
      case "glow": return [p.threshold, p.radius, p.intensity, p.knee, p.saturation];
    }
  }

  private drawPass(
    texture: WebGLTexture,
    target: Target | null,
    effect: EffectNode | null,
    time: number,
    channels?: [WebGLTexture, WebGLTexture, WebGLTexture],
    parameterOverrides?: number[],
  ) {
    const gl = this.gl;
    gl.bindFramebuffer(gl.FRAMEBUFFER, target?.framebuffer || null);
    gl.viewport(0, 0, this.canvas.width, this.canvas.height);
    gl.useProgram(this.program);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.uniform1i(this.uniforms.get("u_texture")!, 0);
    const channelTextures = channels || [texture, texture, texture];
    channelTextures.forEach((channelTexture, index) => {
      gl.activeTexture(gl.TEXTURE1 + index);
      gl.bindTexture(gl.TEXTURE_2D, channelTexture);
      gl.uniform1i(this.uniforms.get(["u_texture_r", "u_texture_g", "u_texture_b"][index])!, index + 1);
    });
    gl.activeTexture(gl.TEXTURE0);
    gl.uniform2f(this.uniforms.get("u_resolution")!, this.canvas.width, this.canvas.height);
    gl.uniform1f(this.uniforms.get("u_time")!, time);
    gl.uniform1i(this.uniforms.get("u_effect")!, effect ? this.effectCode(effect.kind) : 0);
    gl.uniform1f(this.uniforms.get("u_mix")!, effect ? this.effectParam(effect, "mix", time) : 1);
    const values = parameterOverrides || (effect ? this.effectValues(effect, time) : []);
    for (let i = 0; i < 8; i++) gl.uniform1f(this.uniforms.get(`u_p${i}`)!, values[i] || 0);
    gl.drawArrays(gl.TRIANGLES, 0, 6);
  }

  private rgbDelayChannels(effect: EffectNode, texture: WebGLTexture, time: number): [WebGLTexture, WebGLTexture, WebGLTexture] {
    const delays = ["redDelay", "greenDelay", "blueDelay"].map((key) =>
      Math.min(24, Math.abs(Math.round(this.effectParam(effect, key, time)))));
    const capacity = Math.max(...delays) + 1;
    let history = this.effectHistories.get(effect.id);
    if (!history || history.targets.length !== capacity) {
      if (history) {
        for (const target of history.targets) {
          this.gl.deleteFramebuffer(target.framebuffer);
          this.gl.deleteTexture(target.texture);
        }
      }
      history = {
        targets: Array.from({ length: capacity }, () => this.createTarget()),
        writeIndex: 0,
        count: 0,
        lastTime: -1,
      };
      this.effectHistories.set(effect.id, history);
    }
    const frameDuration = 1 / Math.max(1, this.project.settings.fps);
    if (history.lastTime >= 0 && (time <= history.lastTime || time - history.lastTime > frameDuration * 2.5)) {
      history.writeIndex = 0;
      history.count = 0;
    }
    this.drawPass(texture, history.targets[history.writeIndex], null, time);
    history.writeIndex = (history.writeIndex + 1) % history.targets.length;
    history.count = Math.min(history.targets.length, history.count + 1);
    history.lastTime = time;
    return delays.map((delay) => {
      if (delay >= history!.count) return texture;
      const index = (history!.writeIndex - 1 - delay + history!.targets.length) % history!.targets.length;
      return history!.targets[index].texture;
    }) as [WebGLTexture, WebGLTexture, WebGLTexture];
  }

  private blendFor(mode: string) {
    const gl = this.gl;
    gl.enable(gl.BLEND);
    gl.blendEquation(gl.FUNC_ADD);
    if (mode === "add") gl.blendFunc(gl.SRC_ALPHA, gl.ONE);
    else if (mode === "multiply") gl.blendFunc(gl.DST_COLOR, gl.ONE_MINUS_SRC_ALPHA);
    else if (mode === "screen") gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_COLOR);
    else if (mode === "lighten") {
      gl.blendEquation(gl.MAX);
      gl.blendFunc(gl.ONE, gl.ONE);
    } else if (mode === "darken") {
      gl.blendEquation(gl.MIN);
      gl.blendFunc(gl.ONE, gl.ONE);
    }
    else gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
  }

  private compositeRaster(layer: Layer, effects: EffectNode[], time: number) {
    const gl = this.gl;
    gl.bindTexture(gl.TEXTURE_2D, this.sourceTexture);
    gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, true);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, this.raster);
    let current = this.sourceTexture;
    let index = 0;
    gl.disable(gl.BLEND);
    for (const effect of effects) {
      if (effect.kind === "blur") {
        const radius = Math.max(0, this.effectParam(effect, "radius", time));
        const quality = Math.max(1, Math.min(3, Math.round(this.effectParam(effect, "quality", time) || 1)));
        for (let pass = 0; pass < quality; pass++) {
          let target = this.targets[index % 2];
          this.drawPass(current, target, effect, time, undefined, [radius / Math.sqrt(quality), 0]);
          current = target.texture;
          index++;
          target = this.targets[index % 2];
          this.drawPass(current, target, effect, time, undefined, [radius / Math.sqrt(quality), 1]);
          current = target.texture;
          index++;
        }
      } else {
        const target = this.targets[index % 2];
        this.drawPass(current, target, effect, time);
        current = target.texture;
        index++;
      }
    }
    this.blendFor(layer.blendMode);
    this.drawPass(current, this.compTarget, null, time);
  }

  async render(time: number, exporting = false) {
    this.ensureRenderScale(exporting ? 1 : this.previewScale);
    const gl = this.gl;
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.compTarget.framebuffer);
    gl.viewport(0, 0, this.canvas.width, this.canvas.height);
    const bg = this.project.settings.transparent ? [0, 0, 0, 0] : this.hex(this.project.settings.background);
    gl.disable(gl.BLEND);
    gl.clearColor(bg[0], bg[1], bg[2], bg[3]);
    gl.clear(gl.COLOR_BUFFER_BIT);

    for (const layer of [...this.project.layers].reverse()) {
      if (!layer.visible || (exporting && !layer.exportable) || time < layer.startTime || time > layer.endTime) continue;
      const enabledEffects = layer.effects.filter((item) => item.enabled);
      const trail = enabledEffects.find((effect) => effect.kind === "feedback");
      const visualEffects = enabledEffects.filter((effect) => effect !== trail);
      if (!trail) {
        if (await this.rasterize(layer, time, exporting)) this.compositeRaster(layer, visualEffects, time);
        continue;
      }
      const requestedCount = Math.round(this.effectParam(trail, "count", time));
      const previewLimit = layer.kind === "video" && !exporting ? 10 : 32;
      const count = Math.max(1, Math.min(previewLimit, requestedCount));
      const spacing = Math.max(0, this.effectParam(trail, "spacing", time));
      const decay = Math.max(0.05, Math.min(1, this.effectParam(trail, "decay", time)));
      const offsetX = this.effectParam(trail, "offsetX", time);
      const offsetY = this.effectParam(trail, "offsetY", time);
      for (let index = count - 1; index >= 0; index--) {
        const sampleTime = time - index * spacing;
        if (sampleTime < layer.startTime || sampleTime > layer.endTime) continue;
        const ready = await this.rasterize(
          layer,
          sampleTime,
          exporting,
          Math.pow(decay, index),
          offsetX * index,
          offsetY * index,
        );
        if (ready) this.compositeRaster(layer, visualEffects, time);
      }
    }

    gl.disable(gl.BLEND);
    let current = this.compTarget.texture;
    let index = 0;
    for (const effect of this.project.postEffects.filter((item) => item.enabled)) {
      const target = this.targets[index % 2];
      const channels = effect.kind === "rgbDelay" ? this.rgbDelayChannels(effect, current, time) : undefined;
      this.drawPass(current, target, effect, time, channels);
      current = target.texture;
      index++;
    }
    this.drawPass(current, null, null, time);
  }

  framePngBase64() {
    return this.canvas.toDataURL("image/png").split(",")[1];
  }

  private hex(value: string): [number, number, number, number] {
    const match = value.replace("#", "");
    const full = match.length === 3 ? match.split("").map((v) => v + v).join("") : match.padEnd(6, "0");
    return [parseInt(full.slice(0, 2), 16) / 255, parseInt(full.slice(2, 4), 16) / 255, parseInt(full.slice(4, 6), 16) / 255, 1];
  }
}
